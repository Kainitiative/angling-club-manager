<?php
return [
    'db' => [
        'driver' => 'pgsql',
        'host' => getenv('PGHOST') ?: 'localhost',
        'port' => getenv('PGPORT') ?: '5432',
        'name' => getenv('PGDATABASE') ?: 'angling_club_manager',
        'user' => getenv('PGUSER') ?: 'root',
        'pass' => getenv('PGPASSWORD') ?: '',
        'charset' => 'utf8',
    ],
    'base_url' => getenv('REPL_SLUG') ? '' : '',
];
