ALTER TABLE clubs ADD COLUMN constitution TEXT NULL;
ALTER TABLE clubs ADD COLUMN rules_policies TEXT NULL;
ALTER TABLE clubs ADD COLUMN privacy_policy TEXT NULL;
ALTER TABLE clubs ADD COLUMN membership_terms TEXT NULL;
