-- Add is_pinned column to club_news table
ALTER TABLE club_news ADD COLUMN IF NOT EXISTS is_pinned TINYINT(1) NOT NULL DEFAULT 0 AFTER is_published;
