<?php
echo "PHP Works! Version: " . phpversion();
