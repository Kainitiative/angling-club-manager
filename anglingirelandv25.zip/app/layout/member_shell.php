<?php
/**
 * Member Shell - Layout for logged-in user personal pages
 * (Dashboard, Messages, Notifications, Tasks, Profile, etc.)
 * 
 * Usage:
 * $pageTitle = 'Dashboard';
 * $currentPage = 'home';
 * include 'app/layout/member_shell.php';
 * member_shell_start($pdo);
 * // ... your content here ...
 * member_shell_end();
 */

require_once __DIR__ . '/../nav_config.php';

function member_shell_start($pdo, $options = []) {
    global $pageTitle, $currentPage;
    
    $userId = current_user_id();
    $user = current_user($pdo);
    
    $pageTitle = $options['title'] ?? $pageTitle ?? 'Dashboard';
    $currentPage = $options['page'] ?? $currentPage ?? 'home';
    $section = $options['section'] ?? '';
    
    $clubContext = $options['club'] ?? null;
    $clubNav = null;
    
    if ($clubContext && isset($clubContext['id'], $clubContext['slug'])) {
        $clubNav = get_club_admin_nav($clubContext['id'], $clubContext['slug']);
    }
    
    // Get badge counts - stored globally so shell_end can access them
    global $__member_shell_unread_notifications, $__member_shell_unread_messages;
    $unreadNotifications = 0;
    $unreadMessages = 0;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$userId]);
        $unreadNotifications = (int)$stmt->fetchColumn();
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM club_messages WHERE recipient_id = ? AND is_read = 0");
        $stmt->execute([$userId]);
        $unreadMessages = (int)$stmt->fetchColumn();
    } catch (Exception $e) {}
    
    $__member_shell_unread_notifications = $unreadNotifications;
    $__member_shell_unread_messages = $unreadMessages;
    
    $nav = get_member_nav($pdo, $userId);
    $breadcrumbs = get_breadcrumbs('member', ['section' => $section]);
    $isSuperAdmin = function_exists('is_super_admin') && is_super_admin($pdo);
    
    $avatarUrl = !empty($user['avatar_url']) ? $user['avatar_url'] : 'https://www.gravatar.com/avatar/' . md5(strtolower(trim($user['email'] ?? ''))) . '?d=mp&s=80';
    
    include __DIR__ . '/header.php';
?>
<div class="layout-sidebar">
    <div class="sidebar-overlay"></div>
    
    <aside class="sidebar">
        <div class="sidebar-header">
            <a href="/public/dashboard.php" class="sidebar-brand">
                <i class="bi bi-water"></i>
                Angling Ireland
            </a>
        </div>
        
        <nav class="sidebar-nav">
            <div class="sidebar-section">
                <div class="sidebar-section-title">Main</div>
                <?php foreach ($nav['main'] as $item): ?>
                    <a href="<?= e($item['url']) ?>" class="sidebar-link <?= $currentPage === $item['id'] ? 'active' : '' ?>">
                        <i class="bi bi-<?= $item['icon'] ?>"></i>
                        <?= e($item['label']) ?>
                    </a>
                <?php endforeach; ?>
            </div>
            
            <div class="sidebar-section">
                <div class="sidebar-section-title">Personal</div>
                <?php foreach ($nav['personal'] as $item): ?>
                    <?php 
                    $badge = 0;
                    if (($item['badge'] ?? '') === 'notifications') $badge = $unreadNotifications;
                    if (($item['badge'] ?? '') === 'messages') $badge = $unreadMessages;
                    ?>
                    <a href="<?= e($item['url']) ?>" class="sidebar-link <?= $currentPage === $item['id'] ? 'active' : '' ?>">
                        <i class="bi bi-<?= $item['icon'] ?>"></i>
                        <?= e($item['label']) ?>
                        <?php if ($badge > 0): ?>
                            <span class="badge bg-danger sidebar-badge"><?= $badge > 99 ? '99+' : $badge ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
            
            <?php if ($clubNav && $clubContext): ?>
            <div class="sidebar-section">
                <div class="sidebar-section-title"><?= e($clubContext['name'] ?? 'Club') ?></div>
                <?php foreach ($clubNav as $section): ?>
                    <?php foreach ($section['items'] as $item): ?>
                        <a href="<?= e($item['url']) ?>" class="sidebar-link <?= $currentPage === $item['id'] ? 'active' : '' ?>">
                            <i class="bi bi-<?= $item['icon'] ?>"></i>
                            <?= e($item['label']) ?>
                        </a>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <?php if ($isSuperAdmin): ?>
            <div class="sidebar-section">
                <div class="sidebar-section-title">Admin</div>
                <a href="/public/superadmin/" class="sidebar-link <?= $currentPage === 'superadmin' ? 'active' : '' ?>">
                    <i class="bi bi-shield-lock"></i>
                    Super Admin
                </a>
            </div>
            <?php endif; ?>
        </nav>
        
        <div class="user-menu">
            <div class="dropdown">
                <button class="user-menu-btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <img src="<?= e($avatarUrl) ?>" alt="" class="user-avatar">
                    <span class="text-truncate" style="max-width: 140px;"><?= e($user['name'] ?? 'User') ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-dark">
                    <li><a class="dropdown-item" href="/public/profile.php"><i class="bi bi-person-gear me-2"></i>Edit Profile</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="/public/auth/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </aside>
    
    <main class="main-content">
        <header class="top-bar">
            <div class="d-flex align-items-center gap-3">
                <button class="sidebar-toggle" type="button">
                    <i class="bi bi-list fs-4"></i>
                </button>
                <?= render_breadcrumbs($breadcrumbs) ?>
            </div>
            <div class="d-flex align-items-center gap-2">
                <a href="/public/notifications.php" class="btn btn-light btn-sm position-relative">
                    <i class="bi bi-bell"></i>
                    <?php if ($unreadNotifications > 0): ?>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.65rem;">
                            <?= $unreadNotifications > 9 ? '9+' : $unreadNotifications ?>
                        </span>
                    <?php endif; ?>
                </a>
                <a href="/public/messages.php" class="btn btn-light btn-sm position-relative">
                    <i class="bi bi-envelope"></i>
                    <?php if ($unreadMessages > 0): ?>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.65rem;">
                            <?= $unreadMessages > 9 ? '9+' : $unreadMessages ?>
                        </span>
                    <?php endif; ?>
                </a>
            </div>
        </header>
        
        <div class="content-area">
<?php
}

function member_shell_end($options = []) {
    global $currentPage, $__member_shell_unread_notifications, $__member_shell_unread_messages;
    $unreadNotifications = $options['unreadNotifications'] ?? $__member_shell_unread_notifications ?? 0;
    $unreadMessages = $options['unreadMessages'] ?? $__member_shell_unread_messages ?? 0;
?>
        </div>
        
        <!-- Mobile Bottom Navigation -->
        <nav class="mobile-nav">
            <a href="/public/dashboard.php" class="mobile-nav-item <?= $currentPage === 'home' ? 'active' : '' ?>">
                <i class="bi bi-house"></i>
                <span>Home</span>
            </a>
            <a href="/public/clubs.php" class="mobile-nav-item <?= $currentPage === 'clubs' ? 'active' : '' ?>">
                <i class="bi bi-people"></i>
                <span>Clubs</span>
            </a>
            <a href="/public/competitions.php" class="mobile-nav-item <?= $currentPage === 'competitions' ? 'active' : '' ?>">
                <i class="bi bi-trophy"></i>
                <span>Comps</span>
            </a>
            <a href="/public/messages.php" class="mobile-nav-item <?= $currentPage === 'messages' ? 'active' : '' ?>">
                <i class="bi bi-envelope"></i>
                <span>Messages</span>
                <?php if ($unreadMessages > 0): ?>
                    <span class="mobile-nav-badge"><?= $unreadMessages > 9 ? '9+' : $unreadMessages ?></span>
                <?php endif; ?>
            </a>
            <a href="/public/profile.php" class="mobile-nav-item <?= $currentPage === 'profile' ? 'active' : '' ?>">
                <i class="bi bi-person"></i>
                <span>Profile</span>
            </a>
        </nav>
    </main>
</div>
<?php
    include __DIR__ . '/footer.php';
}
